import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {

	// ball coordinates
	int ballx, bally;

	// bat coordinate for player 1
	int bat1x, bat1y;

	// bat coordinate for player 2
	int bat2x, bat2y;

	// constructor
	public MyPanel() {

		ballx = 30;
		bally = 200;
		
		bat1x = 0;
		bat1y = 180;
		
		bat2x = 0;
		bat2y = 180;
		

	}

	// to draw images on screen
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		

		// draw a green ball
		g.setColor(Color.yellow);
		g.fillOval(ballx, bally, 15, 15);
		
		// creating bats for players
		g.setColor(Color.RED);
		g.fillRoundRect(bat1x+20, bat1y, 10, 100, 10, 10);
		g.setColor(Color.BLUE);
		g.fillRoundRect(bat2x + getWidth() - 30, bat2y, 10, 100, 10, 10);
		g.setColor(Color.black);
		g.drawRect(10, 20, getWidth()-20, getHeight()-30);
	
		
	}

}