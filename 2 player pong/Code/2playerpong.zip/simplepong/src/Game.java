import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Game implements ActionListener {

	JFrame myFrame;
	MyPanel myBat;
	// displaying score
	JLabel lb1, lb2, lb3;

	// to count the score of both players
	int score1;
	int score2;

	int framex=500;
	int framey=500;
	// determine ball direction
	int val;
	// speed of the ball
	int ballspeed = 2;
	// identify which from bat the ball is coming
	boolean bat1 = false, bat2 = false;
	//game paused or not
	boolean unpaused=true;
	// toggle for pause
	int toggle=0;
	// constructor for game
	public Game() {
		score1 = 0;
		score2 = 0;

		initGUI();
	}

	// initGUI() sets the layout of the game. Initializes game layout
	private void initGUI() {

		myFrame = new JFrame();
		myBat = new MyPanel();

		myBat.setBackground(Color.LIGHT_GRAY);
		lb1 = new JLabel("Player 1 = 0");
		lb3 = new JLabel("Controls-P1 a/z | P2-up/down | Pause -Space | SCORES | ");
		lb2 = new JLabel("Player 2 = 0");

		Container c = myFrame.getContentPane();
		c.setLayout(new BorderLayout());

		myBat.add(lb3);
		myBat.add(lb1);
		myBat.add(lb2);
		c.add(myBat);
		myFrame.setSize(500, 500);
		myFrame.setVisible(true);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.addKeyListener(new KeyboradHandler());

		Timer t = new Timer(3, this);
		t.start();

	}

	// *************************************************************************************************
	// refreshes the game screen.. runs the game
	public void actionPerformed(ActionEvent a) {

		if (unpaused){
			determineBallDirection();
			changeBallDirection();
			myBat.repaint();
			//	System.out.println(myBat.ballx);

		}
	}

	// *************************************************************************************************
	// handles the keyevents, moves bats up or down. or pauses the game
	public class KeyboradHandler extends KeyAdapter {
		public void keyPressed(KeyEvent ke) {

			if (ke.getKeyCode() == ke.VK_DOWN)// move the bat2 down
			{
				if (myBat.bat2y < myBat.getHeight()-115) {
					myBat.bat2y += 5;
				}
			}
			if (ke.getKeyCode() == ke.VK_UP)// move the bat2 Up
			{
				if (myBat.bat2y != 20) {
					myBat.bat2y -= 5;
				}
			}

			if (ke.getKeyCode() == ke.VK_Z)// move the bat1 down
			{
				if (myBat.bat1y < myBat.getHeight()-115) {
					myBat.bat1y += 5;
				}
			}
			if (ke.getKeyCode() == ke.VK_A)// move the bat1 Up
			{
				if (myBat.bat1y != 0) {
					myBat.bat1y -= 5;
				}
			}
			if (ke.getKeyCode() == ke.VK_SPACE)// move the bat1 Up
			{
				toggle++;
				if (toggle%2==0){
					unpaused=true;
				}else{
					unpaused=false;
				}
			}

		} // end method keyPressed()

	} // end class KeyBoardHandler

	// *****************************************************************************************************

	// determineBallDirection()
	// method used to determine ball direction
	public void determineBallDirection() {		

		if (bat1 == true && myBat.bally >= myBat.getHeight() - 30) {
			// ball hit bottom boundary and coming from bat 1
			val = 3;

		}

		else if (bat2 == true && myBat.bally >= myBat.getHeight() - 30) {
			// ball hit bottom boundary and coming from bat 2
			val = 2;
		}

		// ball hit top boundary and coming from bat 1
		else if (bat1 == true && myBat.bally <= 20) {
			val = 1;
		}

		// ball hit top boundary and coming from bat 2
		else if (bat2 == true && myBat.bally <= 20) {
			val = 4;
		}

		// *********** check if ball touches bat or not ***** 
		// right bat lower half
		if (myBat.bally > myBat.bat2y + 40
				&& myBat.bally <= myBat.bat2y + 80
				&& myBat.ballx >= (myBat.getWidth() - 40)) {
			val = 4;
			bat2 = true;
			bat1 = false;
		}
		// right bat upper half
		else if (myBat.bally >= myBat.bat2y
				&& myBat.bally <= myBat.bat2y + 40
				&& myBat.ballx >= (myBat.getWidth() - 40)) {
			val = 2;
			bat2 = true;
			bat1 = false;
		}

		//* left bat lower half
		else if (myBat.bally >= myBat.bat1y + 40
				&& myBat.bally <= myBat.bat1y + 80 && myBat.ballx <= 30) {
			val = 1;
			bat1 = true;
			bat2 = false;
		}

		//left bat upper half
		else if (myBat.bally >= myBat.bat1y
				&& myBat.bally <= myBat.bat1y + 40 && myBat.ballx <= 30) {
			val = 3;
			bat1 = true;
			bat2 = false;
		}

		// if the ball goes out of the left or right side. i.e goes past the bat 
		// update the plater score
		if (myBat.ballx >= myBat.getWidth()) {
			score1++;
			//player 1 score is updated
			val = 7;
		}

		else if (myBat.ballx < 0) {
			score2++;
			//player 2 score is updated
			val = 8;
		}

	} // end determineBallDirection()

	// ******************************************************************************************************
	// method is used to change the ball direction according the the val set above
	public void changeBallDirection() {

		switch (val) {
		case 1:
			myBat.ballx += ballspeed;
			myBat.bally += ballspeed;
			break;

		case 2:
			myBat.ballx -= ballspeed;
			myBat.bally -= ballspeed;
			break;

		case 3:
			// hit y at upper limit coming from bat 2
			myBat.ballx += ballspeed;
			myBat.bally -= ballspeed;
			break;

		case 4:

			myBat.ballx -= ballspeed;
			myBat.bally += ballspeed;
			break;

		case 7:
			// Player 1 wins
			myBat.ballx = 30;
			myBat.bally = 200;
			myBat.bat2y = 180;
			myBat.bat1y = 180;
			lb1.setText("Player 1 = " + score1 + "");
			break;

		case 8:
			//Player 2 wins
			myBat.ballx = myBat.getWidth() - 40;
			myBat.bally = 200;
			myBat.bat2y = 180;
			myBat.bat1y = 180;

			lb2.setText("Player 2 = " + score2 + "");
			
			break;

		}// end switch

	} // end method changeBallDirection()

	// *********************************************************************************************************
	
	// Tests for the functions in the program. 
	//
	public void tests(){
		

		boolean b1=false, b2=false, b3=false, b4 =false, p1=false, p2=false;
		while(true){
			
			// check if the val is set properly
			// this val decides how the program behaves
			determineBallDirection();

			if (val == 3 && b1==false){
				System.out.println("test for ball hit BOTTOM boundary and coming from bat 1");
				b1=true;
			}
			if (val == 2 && b2==false){
				System.out.println("test for ball hit BOTTOM boundary and coming from bat 2");
				b2=true;
			}
			if (val == 4 && b3==false)
			{
				System.out.println("test for ball hit top boundary coming from bat 2 passed");
				b3=true;
			}
			if (val == 1 && b4==false)
			{
				System.out.println("test for ball hit top boundary and coming from bat 1 passed");
				b4=true;
			}
			
			if (val == 7 && p1==false)
				{
				System.out.println("test for Player 1 win passed");
				p1=true;
				val=3;
				}
			if (val == 8 && p2==false)
			{
				System.out.println("test for Player 2 win passed");
				p2=true;
				val=3;
			}
			
		}
	}

	public static void main(String[] args)
	{
		//uncomment the below line and run only the file Game.java to run the tests.
		//new Game().tests();
		

	}

}